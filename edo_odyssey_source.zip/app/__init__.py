import os
from flask import Flask
from .extensions import db, login_manager, migrate, csrf
from config import config


def create_app(env="development"):
    app = Flask(
        __name__,
        template_folder="templates",
        static_folder="static",
    )
    app.config.from_object(config[env])

    # Create upload dirs
    for folder in ["attractions", "hotels", "restaurants", "users", "guides", "qr_codes", "events"]:
        os.makedirs(os.path.join(app.config["UPLOAD_FOLDER"], folder), exist_ok=True)

    # Init extensions
    db.init_app(app)
    login_manager.init_app(app)
    migrate.init_app(app, db)
    csrf.init_app(app)

    login_manager.login_view = "auth.login"
    login_manager.login_message = "Please log in to access this page."
    login_manager.login_message_category = "warning"

    # Register blueprints
    from .auth.routes import auth_bp
    from .main.routes import main_bp
    from .attractions.routes import attractions_bp
    from .guides.routes import guides_bp
    from .hotels.routes import hotels_bp
    from .restaurants.routes import restaurants_bp
    from .events.routes import events_bp
    from .news.routes import news_bp
    from .bookings.routes import bookings_bp
    from .reviews.routes import reviews_bp
    from .dashboard.routes import dashboard_bp
    from .search.routes import search_bp
    from .admin.routes import admin_bp
    from .qr.routes import qr_bp
    from .api.routes import api_bp

    app.register_blueprint(auth_bp)
    app.register_blueprint(main_bp)
    app.register_blueprint(attractions_bp)
    app.register_blueprint(guides_bp)
    app.register_blueprint(hotels_bp)
    app.register_blueprint(restaurants_bp)
    app.register_blueprint(events_bp)
    app.register_blueprint(news_bp)
    app.register_blueprint(bookings_bp)
    app.register_blueprint(reviews_bp)
    app.register_blueprint(dashboard_bp)
    app.register_blueprint(search_bp)
    app.register_blueprint(admin_bp)
    app.register_blueprint(qr_bp)
    app.register_blueprint(api_bp)

    # Context processors
    from .utils.helpers import inject_globals
    app.context_processor(inject_globals)

    # Error handlers
    from flask import render_template

    @app.errorhandler(403)
    def forbidden(e):
        return render_template("errors/403.html"), 403

    @app.errorhandler(404)
    def not_found(e):
        return render_template("errors/404.html"), 404

    @app.errorhandler(500)
    def server_error(e):
        return render_template("errors/500.html"), 500

    return app
