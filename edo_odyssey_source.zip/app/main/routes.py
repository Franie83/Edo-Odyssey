from flask import Blueprint, render_template, abort
from ..models.models import Attraction, Hotel, Restaurant, Event, News, Guide, Category, Partner, FAQ

main_bp = Blueprint("main", __name__)


@main_bp.route("/")
def home():
    featured_attractions = Attraction.query.filter_by(featured=True, active=True, status="active").limit(6).all()
    featured_hotels = Hotel.query.filter_by(featured=True, status="active").limit(3).all()
    featured_restaurants = Restaurant.query.filter_by(featured=True, status="active").limit(3).all()
    upcoming_events = Event.query.filter_by(featured=True, active=True, status="active").limit(3).all()
    recent_news = News.query.filter_by(status="active").order_by(News.created_at.desc()).limit(4).all()
    featured_guides = Guide.query.filter_by(verification_status="Approved", status="active").limit(4).all()
    partners = Partner.query.filter_by(active=True).all()
    categories = Category.query.filter_by(type="attraction", status="active").all()
    total_attractions = Attraction.query.filter_by(status="active").count()
    total_guides = Guide.query.filter_by(verification_status="Approved", status="active").count()
    total_hotels = Hotel.query.filter_by(status="active").count()
    return render_template(
        "main/home.html",
        featured_attractions=featured_attractions,
        featured_hotels=featured_hotels,
        featured_restaurants=featured_restaurants,
        upcoming_events=upcoming_events,
        recent_news=recent_news,
        featured_guides=featured_guides,
        partners=partners,
        categories=categories,
        total_attractions=total_attractions,
        total_guides=total_guides,
        total_hotels=total_hotels,
    )


@main_bp.route("/about")
def about():
    return render_template("main/about.html")


@main_bp.route("/contact")
def contact():
    return render_template("main/contact.html")


@main_bp.route("/privacy")
def privacy():
    return render_template("main/privacy.html")


@main_bp.route("/terms")
def terms():
    return render_template("main/terms.html")


@main_bp.route("/faq")
def faq():
    faqs = FAQ.query.filter_by(active=True).order_by(FAQ.order).all()
    return render_template("main/faq.html", faqs=faqs)
