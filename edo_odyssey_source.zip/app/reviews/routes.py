from flask import Blueprint, render_template, request, flash, redirect, url_for
from flask_login import login_required, current_user
from ..models.models import Review
from ..extensions import db
from ..utils.helpers import log_action

reviews_bp = Blueprint("reviews", __name__, url_prefix="/reviews")


@reviews_bp.route("/add/<target_type>/<int:target_id>", methods=["POST"])
@login_required
def add_review(target_type, target_id):
    allowed = ["Attraction", "Hotel", "Guide", "Restaurant"]
    if target_type not in allowed:
        flash("Invalid review target.", "danger")
        return redirect(url_for("main.home"))

    rating = int(request.form.get("rating", 5))
    comment = request.form.get("comment", "").strip()
    redirect_url = request.form.get("redirect_url", url_for("main.home"))

    if not (1 <= rating <= 5) or not comment:
        flash("Please provide a valid rating and comment.", "warning")
        return redirect(redirect_url)

    # Check if already reviewed
    existing = Review.query.filter_by(
        user_id=current_user.id, target_type=target_type, target_id=target_id
    ).first()
    if existing:
        existing.rating = rating
        existing.comment = comment
        db.session.commit()
        flash("Your review has been updated.", "success")
    else:
        review = Review(
            user_id=current_user.id,
            target_type=target_type,
            target_id=target_id,
            rating=rating,
            comment=comment,
            is_approved=True,
            status="active",
        )
        db.session.add(review)
        db.session.commit()
        flash("Review submitted! Thank you.", "success")

    log_action(f"Submitted {rating}-star review on {target_type} #{target_id}", module="reviews")
    return redirect(redirect_url)
