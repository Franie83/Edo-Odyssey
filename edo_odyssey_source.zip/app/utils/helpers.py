import os
import re
import json
import uuid
import random
import string
from datetime import datetime
from flask import request
from flask_login import current_user
from ..extensions import db
from ..models.models import CMSSetting, Notification, AuditLog


def inject_globals():
    """Inject global variables into all templates."""
    cms_raw = CMSSetting.query.all()
    cms = {item.key: item.value for item in cms_raw}

    unread_notifs = 0
    if current_user.is_authenticated:
        unread_notifs = Notification.query.filter_by(
            user_id=current_user.id, is_read=False
        ).count()

    return {
        "cms": cms,
        "now": datetime.utcnow(),
        "unread_notifs": unread_notifs,
        "site_name": "Edo Odyssey",
    }


def allowed_file(filename):
    ALLOWED = {"png", "jpg", "jpeg", "gif", "webp"}
    return "." in filename and filename.rsplit(".", 1)[1].lower() in ALLOWED


def save_uploaded_file(file, subfolder="uploads"):
    from flask import current_app
    upload_dir = os.path.join(current_app.config["UPLOAD_FOLDER"], subfolder)
    os.makedirs(upload_dir, exist_ok=True)
    ext = file.filename.rsplit(".", 1)[1].lower()
    filename = f"{uuid.uuid4().hex}.{ext}"
    path = os.path.join(upload_dir, filename)
    file.save(path)
    return f"/static/uploads/{subfolder}/{filename}"


def log_action(action, module=None, record_id=None):
    """Write an audit log entry for the current user."""
    try:
        email = current_user.email if current_user.is_authenticated else "system"
        role = current_user.role if current_user.is_authenticated else "system"
        uid = current_user.id if current_user.is_authenticated else None
        log = AuditLog(
            user_id=uid,
            operator_email=email,
            role=role,
            action=action,
            ip_address=request.remote_addr,
            user_agent=request.user_agent.string[:255] if request.user_agent else None,
            module=module,
            record_id=record_id,
        )
        db.session.add(log)
        db.session.commit()
    except Exception:
        pass


def create_notification(user_id, title, message, type_="info", link=None):
    notif = Notification(
        user_id=user_id,
        title=title,
        message=message,
        type=type_,
        link=link,
    )
    db.session.add(notif)
    db.session.commit()


def generate_reference():
    return "EO" + "".join(random.choices(string.ascii_uppercase + string.digits, k=8))


def slugify(text):
    text = text.lower()
    text = re.sub(r"[^\w\s-]", "", text)
    text = re.sub(r"[\s_-]+", "-", text)
    return text.strip("-")


def star_range(rating):
    return range(1, 6)


def paginate_query(query, page, per_page=12):
    return query.paginate(page=page, per_page=per_page, error_out=False)
